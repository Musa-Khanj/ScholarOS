# ScholarOS CLI — Part 2 Implementation

This package adds the first CLI boundary without changing the frozen
ScholarOS core architecture.

## Files

- `scholaros/cli/__init__.py`
- `scholaros/cli/__main__.py`
- `scholaros/cli/parser.py`
- `scholaros/cli/commands.py`
- `scholaros/cli/main.py`
- `tests/test_cli.py`

## Existing file to update

Add the following console-script entry to the existing `[project.scripts]`
section of `pyproject.toml`:

```toml
[project.scripts]
scholaros = "scholaros.cli.main:main"
```

If `[project.scripts]` already exists, add only the `scholaros = ...` line.

## Verification

From the project root:

```powershell
pytest tests/test_cli.py -v
python -m scholaros --version
python -m scholaros info
python -m scholaros status
```

Then run the complete regression suite:

```powershell
pytest -v
```

Do not modify the existing core, runtime, research, retrieval, knowledge,
or RAG implementations as part of this CLI step.
