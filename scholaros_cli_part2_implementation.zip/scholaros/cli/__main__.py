"""
ScholarOS CLI module entry point.
"""

from __future__ import annotations

from scholaros.cli.main import main


if __name__ == "__main__":
    raise SystemExit(
        main()
    )
